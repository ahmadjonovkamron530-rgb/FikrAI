FikrAI — maktabga yo'naltirilgan AI prototipi

MUHIM:
- Bu loyiha statik HTMLning o'zi bilan ishlamaydi: Node.js serveri kerak.
- Haqiqiy AI javoblari uchun OpenAI API kaliti va API hisobida foydalanish huquqi/balans kerak bo'lishi mumkin.
- API kalitini public GitHub repo, index.html yoki boshqa brauzer kodiga HECH QACHON joylamang.
- Moderatsiya va prompt cheklovlari xatoni to'liq kafolat bilan to'smaydi. Ishga tushirishdan oldin test qiling va nazorat qiling.
- API orqali yuborilgan savollar tashqi AI xizmatiga uzatiladi; foydalanuvchilarga buni maxfiylik bildirishnomasida ayting.

Mahalliy ishga tushirish:
1. Kompyuterga Node.js o'rnating.
2. Ushbu papkada terminal oching.
3. `npm install` buyrug'ini bajaring.
4. `.env.example` faylidan nusxa olib `.env` deb nomlang.
5. `.env` ichidagi OPENAI_API_KEY qiymatiga maxfiy API kalitni yozing.
6. `npm start` buyrug'ini bajaring.
7. Brauzerda http://localhost:3000 manzilini oching.

Joylash:
GitHub Pages faqat statik HTMLni joylaydi, u server.js ni ishga tushirmaydi.
Shuning uchun bu versiyani server ishlata oladigan hostingga joylash kerak.
API kalitini hosting xizmatining Environment Variables/Secrets sozlamasiga kiriting.
Public GitHub repoga .env faylini yuklamang.

Xavfsizlik:
- Savol moderatsiyadan o'tadi.
- AI ga faqat maktab ta'limi mavzularida javob berish ko'rsatmasi beriladi.
- Yaratilgan javob ham moderatsiyadan o'tadi.
- Maktabga aloqadorlikni aniqlash AI ko'rsatmasiga tayanadi; u mutlaq kafolat emas.
